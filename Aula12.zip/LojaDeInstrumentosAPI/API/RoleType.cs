﻿namespace LojaDeInstrumentosAPI.API
{
    public enum RoleType
    {
        Common,
        Admin
    }
}
