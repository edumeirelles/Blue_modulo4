﻿namespace LojaDeInstrumentosAPI.API
{
    public enum RoleType
    {
        Admin,
        Common
    }
}
