﻿using LojaDeInstrumentosAPI.Data;
using LojaDeInstrumentosAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace LojaDeInstrumentosAPI.Services
{
    public class InstrumentSqlService : IInstrumentService
    {
        LojaDeInstrumentosAPIContext _context;
        public InstrumentSqlService(LojaDeInstrumentosAPIContext context)
        {
            _context = context;
        }
        public List<Instrument> All()
        {
            return _context.Instrument.ToList();
        }
        public bool Create(Instrument instrument)
        {
            try
            {
                _context.Add(instrument);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public bool Delete(int? id)
        {
            if (!_context.Instrument.Any(x => x.Id == id))                
                return false;
            try
            {
                _context.Remove(this.Get(id));
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
        public Instrument Get(int? id)
        {
            return _context.Instrument.FirstOrDefault(x => x.Id == id);
        }
        public bool Update(Instrument instrument)
        {
            if (!_context.Instrument.Any(x => x.Id == instrument.Id))
                return false;
            try
            {
                _context.Update(instrument);
                _context.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}